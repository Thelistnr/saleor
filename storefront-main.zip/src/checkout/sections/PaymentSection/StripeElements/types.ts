export const stripeGatewayId = "app.saleor.stripe";
export type StripeGatewayId = typeof stripeGatewayId;
