export const alertsContainerProps = {
	autoClose: 4000,
	hideProgressBar: true,
	closeButton: () => null,
	closeOnClick: false,
};
